import "./styles.css";
import React, { useState } from "react";
import ReactDOM from "react-dom";
import SignIn from "./components/SignIn";
import Scoreboard from "./scoreboard";

const wordList = ["Schweiz", "Deutschland", "Spanien", "Italien", "Frankreich"];
const categories = ["Länder"];

const vowels = ["A", "E", "I", "O", "U"];

const getRandomWord = () => {
  const index = Math.floor(Math.random() * wordList.length);
  return wordList[index];
};

const getRandomCategory = () => {
  const index = Math.floor(Math.random() * categories.length);
  return categories[index];
};

const Game = () => {
  const [word, setWord] = useState(getRandomWord(getRandomCategory()).toUpperCase());
  const [category, setCategory] = useState(getRandomCategory());
  const [guesses, setGuesses] = useState([]);
  const [lives, setLives] = useState(3);
  const [score, setScore] = useState(0);
  const [wordGuess, setWordGuess] = useState("");
  const [text, setText] = useState("");
  const [hasSpun, setHasSpun] = useState(false);
  const [isSpinDisabled, setIsSpinDisabled] = useState(true);

  const isVowel = (letter) => {
    return vowels.includes(letter);
  };

  const handleGuess = (event) => {
    event.preventDefault();
    const letter = event.target.value.toUpperCase();
    if (event.keyCode === 8 || (!isVowel(letter) && letter !== "" && !guesses.includes(letter))) {
      if (word.includes(letter)) {
        setGuesses([...guesses, letter]);
        if (!word.split("").some((char) => !guesses.includes(char))) {
          setScore(score + 250);
          alert("Du hast gewonnen!");
          setTimeout(() => {
            setWord(getRandomWord().toUpperCase());
            setCategory(getRandomCategory());
            setGuesses([]);
            setLives(3);
            setWordGuess("");
            setIsSpinDisabled(true);
            setHasSpun(false);
          }, 1500);
        } else {
          setIsSpinDisabled(false);
          setScore(score + 100);
        }
      } else {
        setGuesses([...guesses, letter]);
        setLives(lives - 1);
        if (lives === 1) {
          alert("Du hast verloren!");
          setTimeout(() => {
            setWord(getRandomWord().toUpperCase());
            setCategory(getRandomCategory());
            setGuesses([]);
            setLives(3);
            setScore(0);
            setWordGuess("");
            setIsSpinDisabled(true);
            setHasSpun(false);
          }, 1500);
        } else {
          setIsSpinDisabled(false);
          setHasSpun(false);
        }
      }
    } else if (isVowel(letter)) {
      alert("Du darfst nur Konsonanten eingeben!");
      event.target.value = "";
    }
  };

  const handleWordGuess = (event, letter) => {
    event.preventDefault();
    const guess = wordGuess.toUpperCase();
    if (guess === word) {
      setScore(score + 250);
      alert("Du hast gewonnen!");
      setTimeout(() => {
        setWord(getRandomWord().toUpperCase());
        setCategory(getRandomCategory());
        setGuesses([]);
        setLives(3);
        setWordGuess("");
        setIsSpinDisabled(true);
        setHasSpun(false);
      }, 1500);
    } else {
      if (letter && score >= 100) {
        setGuesses(guess.toUpperCase() + letter);
        setScore(score - 100);
      } else {
        setLives(lives - 1);
        if (lives === 1) {
          alert("Du hast verloren!");
          setTimeout(() => {
            setWord(getRandomWord().toUpperCase());
            setCategory(getRandomCategory());
            setGuesses([]);
            setLives(3);
            setScore(0);
            setWordGuess("");
            setIsSpinDisabled(true);
            setHasSpun(false);
          }, 1500);
        } else {
          setHasSpun(false);
        }
      }
    }
  };
  
  const handleBack = (e) => {
    e.preventDefault();
      const root = ReactDOM.createRoot(document.getElementById('root'));
      root.render(
        <React.StrictMode>
          <SignIn/>
        </React.StrictMode>
      );
  };
  
  const handleScore = (e) => {
    e.preventDefault();
      const root = ReactDOM.createRoot(document.getElementById('root'));
      root.render(
        <React.StrictMode>
          <Scoreboard/>
        </React.StrictMode>
      );
  };

  const handleClick = () => {
    if (hasSpun) {
      return; // prevent spinning again while the wheel is still spinning
    }
    const texts = [
      '50',
      '75',
      '100',
      '125',
      '150',
      '200',
      'Bankrott'
    ];
    const randomIndex = Math.floor(Math.random() * texts.length);
    setText(texts[randomIndex]);
    setHasSpun(true); // prevent spinning again until the wheel stops
    if (texts[randomIndex] === 'Bankrott') {
      setScore(0); // set score to zero if Bankrott is landed on
      setTimeout(() => {
        setWord(getRandomWord().toUpperCase());
        setCategory(getRandomCategory());
        setGuesses([]);
        setLives(3);
        setWordGuess("");
        setHasSpun(false); // allow spinning again
      }, 1500); // wait for 2 seconds before resetting the game
    }
  };
  



  return (
    <div> 
      <div className="sign-in-container">

        <div className="gamefield">

          <div className="titel">
            <button onClick={handleBack}>Home</button>
            <button onClick={handleScore}>Highscoreliste</button>
            <h1>{category}</h1> 
          </div>

          <div>
            <h2 style={{ textAlign: "center" }}>{word.split("").map((char) => (guesses.includes(char) ? char : "_")).join(" ")}</h2>
          </div>

          <div className="inputgamefield">
            <div className="inputBox">
              <input type="text" maxLength="1" onChange={handleGuess} placeholder="Rate einen Buchstaben"/>
            </div>

            <br></br>

            <div className="inputBox">
              <input 
              type="text" 
              value={wordGuess} 
              onChange={(event) => setWordGuess(event.target.value)} 
              placeholder="Rate ein Wort"/>
            </div>
              <br></br>

            <div>
              <button onClick={handleWordGuess} className="submit">Bestätigen</button>
            </div> 
          </div>    

          <br></br>
       
            <div className='fieldspin'>
              <textarea value={text} readOnly />
            </div>

            <div className="submit">    
              <button onClick={handleClick}>Drehen</button>
            </div>

            <p className="voweltitle">Vokale kaufen für 100.-</p>
            <div className="vowels">
              <button disabled={score < 100} onClick={(e) => handleWordGuess(e, 'A')}>A</button>
              <button disabled={score < 100} onClick={(e) => handleWordGuess(e, 'E')}>E</button> 
              <button disabled={score < 100} onClick={(e) => handleWordGuess(e, 'I')}>I</button> 
              <button disabled={score < 100} onClick={(e) => handleWordGuess(e, 'O')}>O</button> 
              <button disabled={score < 100} onClick={(e) => handleWordGuess(e, 'U')}>U</button> 
            </div> 

          <div className="lives">
              <p>Lebenspunkte: {lives}/3</p>
          </div>
          <div className="money">
              <p>Kontostand: {score}.-</p>
          </div>

        </div>
      </div>
    </div>
  );
};
  
export default Game;