// Import the functions you need from the SDKs you need
import { initializeApp } from "firebase/app";
import { getAuth } from "firebase/auth";
import { getFirestore } from "firebase/firestore";
// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries

// Your web app's Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyBm7aS6FYYJHjXcoEpFEByCP-WsjOgJDsA",
  authDomain: "auth-gluecksrad.firebaseapp.com",
  projectId: "auth-gluecksrad",
  storageBucket: "auth-gluecksrad.appspot.com",
  messagingSenderId: "153435393345",
  appId: "1:153435393345:web:22933db4f6c94e08dee5c0"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);


export const auth = getAuth(app);   