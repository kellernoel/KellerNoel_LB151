import { signInWithEmailAndPassword } from "firebase/auth";
import React, { useState } from "react";
import { auth } from "../firebase";
import Admin from "../admin";
import Game from "../game";
import ReactDOM from 'react-dom/client';
import '../styles.css';


const SignIn = () => {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");

  const signIn = (e) => {
    e.preventDefault();
    signInWithEmailAndPassword(auth, email, password)
      .then((userCredential) => {
        const root = ReactDOM.createRoot(document.getElementById('root'));
        root.render(
          <React.StrictMode>
            <Admin />
          </React.StrictMode>
        );
        console.log(userCredential);
      })
      .catch((error) => {
        console.log(error);
      });
  };

  const handlePlay = (e) => {
    e.preventDefault();
    const root = ReactDOM.createRoot(document.getElementById('root'));
    root.render(
      <React.StrictMode>
        <Game/>
      </React.StrictMode>
    );
  };

  return (
    <div className="sign-in-container">
      <form onSubmit={signIn}>
        <h1>Loginseite</h1>
        <br></br>
        <p className="titel">Gib deinen Namen ein um zu spielen</p>
        <div className="inputBox">
            <input
                placeholder="Name"/>
        </div>
        <br></br>
        <div>
          <button type="submit" className="Loginbutton" onClick={handlePlay}>Spielen</button>
        </div>
        <br></br>
        <p className="titel">Adminlogin</p>
        <div className="inputBox">
            <input
                type="email"
                placeholder="E-Mail"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
            ></input>
            <span>email</span>
        </div>
        <br></br>
        <div className="inputBox">
            <input
                type="password"
                placeholder="Passwort"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
            ></input>
            <span>password</span>
        </div>

          <br></br>

        <div>
          <button type="submit" className="Loginbutton">Login</button>
        </div>

          <br></br>

      </form>
    </div>
    
  );
};

export default SignIn;