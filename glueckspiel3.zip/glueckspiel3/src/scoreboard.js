import React, { useState } from "react";
import './styles.css';
import SignIn from './components/SignIn';
import ReactDOM from 'react-dom/client';

function AdminPage() {
  const [words, setWords] = useState([]);
  const [categories, setCategories] = useState([]);
  const [highscores, setHighscores] = useState([]);

  // Funktionen zum Anlegen, Ändern und Löschen von Words
  const addWord = (newWord) => {
    setWords((prevState) => [...prevState, newWord]);
  };

  const updateWord = (id, updatedWord) => {
    setWords((prevState) =>
      prevState.map((word) => (word.id === id ? updatedWord : word))
    );
  };

  const deleteWord = (id) => {
    setWords((prevState) => prevState.filter((word) => word.id !== id));
  };

  // Funktionen zum Anlegen und Zuordnen von Kategorien
  const addCategory = (newCategory) => {
    setCategories((prevState) => [...prevState, newCategory]);
  };

  const assignCategory = (wordId, categoryId) => {
    setWords((prevState) =>
      prevState.map((word) =>
        word.id === wordId
          ? { ...word, categoryId: categoryId }
          : word
      )
    );
  };

  // Funktion zum Löschen von Einträgen aus der Highscore-Liste
  const deleteHighscore = (id) => {
    setHighscores((prevState) =>
      prevState.filter((highscore) => highscore.id !== id)
    );
  };

  const handleAddWord = () => {
    // Hier kommt der Code zum Anlegen eines Words
  };

  const handleUpdateWord = () => {
    // Hier kommt der Code zum Aktualisieren eines Words
  };

  const handleDeleteWord = () => {
    // Hier kommt der Code zum Löschen eines Words
  };

  const handleBack = (e) => {
    e.preventDefault();
      const root = ReactDOM.createRoot(document.getElementById('root'));
      root.render(
        <React.StrictMode>
          <SignIn/>
        </React.StrictMode>
      );
  };

  return (
    <div className="sign-in-container">

        <h1>Highscoreliste</h1>

            <div className="homefromadmin">
                <button onClick={handleBack}>Home</button>
            </div>
          
    <table>
      <thead>
        <tr>
          <th>Rang</th>
          <th>Name</th>
          <th>Wann</th>
          <th>Geldbetrag</th>
          <th className="playedgames">Spielrunden</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <td>1</td>
          <td>-</td>
          <td>01.03.2023</td>
          <td>500</td>
          <td className="playedgames">5</td>
        </tr>
        <tr>
          <td>2</td>
          <td>-</td>
          <td>01.03.2023</td>
          <td>400</td>
          <td className="playedgames">4</td>
        </tr>
        <tr>
          <td>3</td>
          <td>-</td>
          <td>01.03.2023</td>
          <td>300</td>
          <td className="playedgames">3</td>
        </tr>
        <tr>
          <td>4</td>
          <td>-</td>
          <td>01.03.2023</td>
          <td>200</td>
          <td className="playedgames">2</td>
        </tr>
        <tr>
          <td>5</td>
          <td>-</td>
          <td>01.03.2023</td>
          <td>100</td>
          <td className="playedgames">1</td>
        </tr>
      </tbody>
    </table>
    </div>
  );
}

export default AdminPage;
