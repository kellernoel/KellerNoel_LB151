import './App.css';
import SignIn from './components/SignIn';
import Game from './game'





function App() {
  return (
    <div className="App">
      <Game/>
    </div>
  );
}

export default App;
