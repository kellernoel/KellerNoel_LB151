import React, { useState, useEffect } from "react";
import ReactDOM from "react-dom";
import SignIn from "./components/SignIn";
import Scoreboard from "./scoreboard";
import "./styles.css";

const categories = [  { name: 'Tiere', words: ['Hund', 'Katze', 'Elefant', 'Giraffe', 'Pinguin'] },
  { name: 'Städte', words: ['Berlin', 'New York', 'Tokio', 'Paris', 'Rom'] },
  { name: 'Länder', words: ['Deutschland', 'USA', 'Japan', 'Frankreich', 'Italien'] }
];

const handleBack = (e) => {
  e.preventDefault();
    const root = ReactDOM.createRoot(document.getElementById('root'));
    root.render(
      <React.StrictMode>
        <SignIn/>
      </React.StrictMode>
    );
};

const handleScore = (e) => {
  e.preventDefault();
    const root = ReactDOM.createRoot(document.getElementById('root'));
    root.render(
      <React.StrictMode>
        <Scoreboard/>
      </React.StrictMode>
    );
};

const vowels = ['a', 'e', 'i', 'o', 'u'];

const Hangman = () => {
  const [category, setCategory] = useState('');
  const [word, setWord] = useState('');
  const [letters, setLetters] = useState([]);
  const [rounds, setRounds] = useState(0);
  const [lives, setLives] = useState(3);
  const [balance, setBalance] = useState(0);
  const [inputLetter, setInputLetter] = useState('');
  const [inputWord, setInputWord] = useState('');
  const [gameKey, setGameKey] = useState(0);

  useEffect(() => {
    const randomCategory = categories[Math.floor(Math.random() * categories.length)];
    setCategory(randomCategory.name);
    const randomWord = randomCategory.words[Math.floor(Math.random() * randomCategory.words.length)].toUpperCase();
    setWord(randomWord);
    setLetters(Array(randomWord.length).fill('_'));
  }, [gameKey]);

  const handleLetterInput = (event) => {
    const input = event.target.value.toUpperCase();
    if (input.match(/^[b-df-hj-np-tv-z]+$/i)) {
      setInputLetter(input);
    }
  };

  const handleWordInput = (event) => {
    const input = event.target.value.toUpperCase();
    setInputWord(input);
  };

  const handleLetterGuess = () => {
    if (inputLetter && letters.includes('_') && lives > 0) {
      const letter = inputLetter;
      setInputLetter('');
      setRounds(rounds + 1);
      if (word.includes(letter)) {
        const newLetters = [...letters];
        for (let i = 0; i < word.length; i++) {
          if (word[i] === letter) {
            newLetters[i] = letter;
            setBalance(balance + 100); // add 100.- to the balance for each correctly guessed letter
            alert("Richtiger Buchstabe!")
          }
        }
        setLetters(newLetters);
      } else {
        setLives(lives - 1);
        alert("Falscher Buchstabe!")
      }
    }
  };

  const handleWordGuess = () => {
    if (inputWord && lives > 0) {
      const guess = inputWord.toUpperCase();
      setInputWord('');
      setRounds(rounds + 1);
      if (guess === word) {
        setLetters(word.split(''));
        setGameKey(gameKey + 1); // update game key to trigger useEffect hook
        setCategory('');
        setWord('');
        setBalance(balance + 250); // add 250.- to the balance for guessing the whole word
        alert("Du hast das Wort geraten, Gratuliere!")
      } else {
        setLives(lives - 1);
        alert("Du hast faslch geraten!")
      }
    }
  };

  const handleVowelPurchase = (vowel) => {
    if (balance >= 100) {
      setBalance(balance - 100);
      const newLetters = [...letters];
      for (let i = 0; i < word.length; i++) {
        if (vowels.includes(word[i])) {
          newLetters[i] = word[i];
        }
      }
      setInputLetter(vowel);
      setLetters(newLetters);
    }
  };


  return (
    <div className='sign-in-container'>
        <div className='gamefield'>
            <div className='titel'>
                <h1>Gluecksrad</h1>
            </div>
            <div className='buttonNavigate'>
                <button onClick={handleScore}>Highscoreliste</button>
                <button onClick={handleBack}>Home</button>
            </div>
                <p>Kategorie: {category}</p>
                <p>Leben: {lives}/3</p>
                <p>Runden: {rounds}</p>
                <p>Kontostand: {balance}.-</p>
                <p>{letters.join(' ')}</p>

            <div className='inputGameField'>
                <div className='inputBox'>
                    <input type="text" value={inputLetter} maxLength={1} onChange={handleLetterInput} />
                </div>

                <div>
                    <button onClick={handleLetterGuess}>Buchstabe raten</button>
                </div>

                    <br></br>

                <div className='inputBox'>
                    <input type="text" value={inputWord} onChange={handleWordInput} />
                </div>

                <div>
                    <button onClick={handleWordGuess}>Wort raten</button>
                </div>
            </div>
            <div>
                <h4>Vokale Kaufen</h4>
            </div>

            <div className='vowels'>
                <button onClick={() => handleVowelPurchase('A')}>A</button>
                <button onClick={() => handleVowelPurchase('E')}>E</button>
                <button onClick={() => handleVowelPurchase('I')}>I</button>
                <button onClick={() => handleVowelPurchase('O')}>O</button>
                <button onClick={() => handleVowelPurchase('U')}>U</button>
            </div>
        </div>
    </div>
  );
};

export default Hangman;

